for f in `ls loop-free-programs/*.bpl`;
do
    ~/BLT/bin/BLT_osx_alpha translate -u=False -f $f >"blt-benchmarks/`basename ${f%.bpl}.p`";
done

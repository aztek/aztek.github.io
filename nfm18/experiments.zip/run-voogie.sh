for f in `ls loop-free-programs/*.bpl`;
do
    ~/voogie/bin/voogie $f >"voogie-benchmarks/`basename ${f%.bpl}.p`";
done

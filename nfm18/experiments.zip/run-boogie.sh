# NB: requires a prepared version of Boogie
for f in `ls loop-free-programs/*.bpl`;
do
    mono ~/boogie-patched/Binaries/Boogie.exe $f /useArrayTheory /z3types | grep SMTLIB | sed 's/\[SMTLIB\] //g' >"boogie-benchmarks/`basename ${f%.bpl}.smt2`";
done

for f in `ls loop-free-programs/*.bpl`;
do
    blt translate -u=False -f $f >"blt-benchmarks/`basename ${f%.bpl}.p`";
done

for f in `ls loop-free-programs/*.bpl`;
do
    echo "Translating $f..."
    voogie $f >"voogie-benchmarks/`basename ${f%.bpl}.p`";
done

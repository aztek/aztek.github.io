TPTP_VAMPIRE="/Users/evgenyk/vampire/vampire_z3_rel_master_3879 --newcnf on -sas z3 -tha some -t 300s"
SMTLIB_VAMPIRE="/Users/evgenyk/vampire/vampire_z3_rel_master_3879 --newcnf on -sas z3 -tha some --input_syntax smtlib2 -t 300s"

for b in `ls tptp-translation`;
do
  echo -en "${b}" '\t'

  TPTP_VAMPIRE_TIME="$(gdate +%s%6N)"
  TPTP_VAMPIRE_OUTPUT=`${TPTP_VAMPIRE} "tptp-translation/$f"`
  TPTP_VAMPIRE_STATUS=$?
  TPTP_VAMPIRE_TIME="$(($(gdate +%s%6N)-TPTP_VAMPIRE_TIME))"

  if [ ${TPTP_VAMPIRE_STATUS} != 0 ]
  then
    echo -n '-'
  else
    echo -n `bc -l <<< "scale=3; ${TPTP_VAMPIRE_TIME}/1000000" | sed 's/^\./0\./'`
  fi
done

# for d in `ls | grep -v .sh`;
# do
#   for f in `ls $d/${UNROLLING}/*.p 2> /dev/null | grep -v loop | sed 's/\.p$//'`;
#   do
#     echo -en "${f}" '\t'

#     TPTP_VAMPIRE_TIME="$(gdate +%s%6N)"
#     TPTP_VAMPIRE_OUTPUT=`${TPTP_VAMPIRE} $f.p`
#     TPTP_VAMPIRE_STATUS=$?
#     TPTP_VAMPIRE_TIME="$(($(gdate +%s%6N)-TPTP_VAMPIRE_TIME))"

#     if [ ${TPTP_VAMPIRE_STATUS} != 0 ]
#     then
#       echo -n '-'
#     else
#       echo -n `bc -l <<< "scale=3; ${TPTP_VAMPIRE_TIME}/1000000" | sed 's/^\./0\./'`
#     fi
#     echo -en '\t'

#     SMTLIB_VAMPIRE_TIME="$(gdate +%s%6N)"
#     SMTLIB_VAMPIRE_OUTPUT=`${SMTLIB_VAMPIRE} $f.smt2`
#     SMTLIB_VAMPIRE_STATUS=$?
#     SMTLIB_VAMPIRE_TIME="$(($(gdate +%s%6N)-SMTLIB_VAMPIRE_TIME))"

#     if [ ${SMTLIB_VAMPIRE_STATUS} != 0 ]
#     then
#       echo -n '-'
#     else
#       echo -n `bc -l <<< "scale=3; ${SMTLIB_VAMPIRE_TIME}/1000000" | sed 's/^\./0\./'`
#     fi
#     echo 
#   done;
# done
